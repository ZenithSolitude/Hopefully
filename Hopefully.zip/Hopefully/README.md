# 🌱 Hopefully

Модульный портал управления сервером. Один бинарник Go, SQLite, HTMX — никакого Docker, никакого npm.

## Установка

```bash
curl -fsSL https://github.com/ZenithSolitude/Hopefully/releases/latest/download/install.sh | sudo bash
```

После установки откройте адрес из вывода скрипта.  
Логин: **admin** / Пароль: **admin** — смените сразу!

## Требования сервера

| | Минимум |
|---|---|
| ОС | Ubuntu 22.04 LTS |
| RAM | 256 MB |
| Диск | 1 GB |
| Архитектура | x86_64 или ARM64 |

Интернет нужен только для установки. После — работает полностью офлайн.

## Управление

```bash
hf status    # состояние сервиса
hf logs      # логи в реальном времени
hf restart   # перезапуск
hf update    # обновить до последней версии
```

## Технологии

| Компонент | Что используется |
|---|---|
| Бэкенд | Go 1.22, стандартная библиотека |
| База данных | SQLite (встроена в бинарник через CGO) |
| Фронтенд | HTML-шаблоны + HTMX (без сборки) |
| Аутентификация | JWT в cookie + bcrypt |
| Метрики | /proc/stat, /proc/meminfo (нативно Linux) |
| Статика | embed.FS (всё вшито в бинарник) |

## Структура проекта

```
cmd/server/           — точка входа (main.go)
internal/
  auth/               — JWT, bcrypt, middleware
  db/                 — SQLite, автомиграции
  modules/            — реестр, установщик, SSE-логи
  system/             — CPU/RAM/disk метрики
web/
  templates/          — HTML-шаблоны (embed в бинарник)
  static/             — CSS, JS (embed в бинарник)
modules-example/
  hello-world/        — пример модуля (Python HTTP-сервер)
install.sh            — установщик для Ubuntu 22.04
.github/workflows/    — CI/CD сборка бинарников
```

## Локальная разработка

```bash
# Требования: Go 1.22+, gcc (для sqlite3)
# Ubuntu/Debian:
sudo apt install golang-go gcc

# Или скачать Go вручную:
# https://go.dev/dl/

git clone https://github.com/ZenithSolitude/Hopefully
cd Hopefully

# Установить зависимости
go mod tidy

# Запустить
SECRET_KEY=devsecret123 go run ./cmd/server -port 8080 -data ./data

# Открыть: http://localhost:8080
# Логин: admin / admin
```

## Написание модуля

Модуль — директория с файлом `manifest.json`:

```json
{
  "name": "my-module",
  "version": "1.0.0",
  "description": "Мой модуль",
  "author": "Имя Автора",

  "entrypoint": "run.sh",
  "port": 9200,

  "requires": ["python3"],

  "menu": {
    "label": "Мой модуль",
    "icon": "🔧",
    "position": 20
  },

  "env": {
    "MY_VAR": "значение"
  }
}
```

`run.sh` — любой скрипт или бинарник. Hopefully передаёт переменные окружения:

| Переменная | Значение |
|---|---|
| `MODULE_NAME` | имя модуля из manifest.json |
| `MODULE_DIR` | путь к файлам модуля на диске |
| `DATA_DIR` | директория для данных модуля |
| `PORT` | HTTP-порт (из manifest.json) |

Если модуль поднимает HTTP-сервер на `PORT` — Hopefully проксирует запросы через `/module-proxy/{name}/` и показывает интерфейс в iframe.

### Установка модуля

**Через веб-интерфейс:** Модули → Установить → вставить GitHub URL или загрузить ZIP.

Если в корне модуля есть `install.sh` — он будет выполнен автоматически (удобно для `pip install`, `apt install`, и т.д.).

## Выпуск релиза

```bash
git tag v1.0.0
git push origin v1.0.0
# GitHub Actions соберёт бинарники для amd64 и arm64
# и опубликует в Releases автоматически
```

## Конфигурация

Файл `/var/lib/hopefully/.env`:

```env
SECRET_KEY=...   # JWT секрет (генерируется автоматически)
PORT=8080        # HTTP порт
DATA_DIR=/var/lib/hopefully
```

## Лицензия

MIT
